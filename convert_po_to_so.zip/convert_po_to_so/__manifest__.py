# -*- coding: utf-8 -*-

{
    'name': 'Convert Purchase Order to Sale Order',
    'version': '1.0',
    'category': 'Sale',
    'sequence': 6,
    'author': 'Webveer',
    'summary': 'Allows you to convert purchase order to sale Order',
    'description': "Allows you to convert purchase order to sale Order",
    'depends': ['sale','purchase'],
    'data': [
        # 'security/ir.model.access.csv',
        'views/views.xml',
        'views/inherit_sale_order_view.xml',
        'wizard/sale_order_wizard_view.xml',
    ],
    'qweb': [
        # 'static/src/xml/pos.xml',
    ],
    'images': [
        'static/description/so.jpg',
    ],
    'installable': True,
    'website': '',
    'auto_install': False,
    'price': 29,
    'currency': 'EUR',
}
