# -*- coding: utf-8 -*-

from odoo import models, fields, api,_
from odoo.exceptions import ValidationError

class ProductProduct(models.Model):
    _inherit = 'product.product'
    
    @api.one
    @api.constrains('default_code','alt_code')
    def _check_unique_constraint(self):
        #record = self.search([('name', '=ilike', self.name),('id','!=',self.id)])
        record1 = self.search([('default_code', '=ilike', self.default_code), ('id', '!=', self.id)])
        record2 = self.search([('alt_code', '=ilike', self.alt_code), ('id', '!=', self.id)])
        if  record1 or record2:
            raise ValidationError(_('Un autre produit de même nom ou réference existe!'))
    
    @api.model
    def create(self, vals):
        res = super(ProductProduct, self).create(vals)
        res.list_price = ((res.standard_price * res.margin_price) / 100) + res.standard_price
        res.name = res.name.rstrip().lstrip()
        return res
    
    @api.multi
    def write(self, vals):
        if 'name' in vals:
            vals['name'] = vals['name'].rstrip().lstrip()
        if 'default_code' in vals:
            vals['default_code'] = vals['default_code'].rstrip().lstrip()
        if 'alt_code' in vals:
            vals['alt_code'] = vals['alt_code'].rstrip().lstrip()
        #vals['list_price'] = ((vals['standard_price'] * vals['margin_price']) / 100) + vals['standard_price']
        #self.list_price = ((self.standard_price * self.margin_price) / 100) + self.standard_price

        return super(ProductProduct, self).write(vals)
    @api.onchange("margin_price","standard_price")
    def onchanginprice(self):
        if self.margin_price or self.standard_price:
         self.list_price = ((self.standard_price * self.margin_price) / 100) + self.standard_price


    default_code=fields.Char('Référence',required=True)
    margin_price=fields.Float('Margin Percentage',default=60.00)
    alt_code = fields.Char('Alternative Number')
    state = fields.Selection(selection=[('ne', 'NE'),
                                        ('sv', 'SV'),
                                        ('fn', 'FN'),
                                        ('oh', 'OH')],
                             string='Etat',
                             default='ne',
                             index=True)
    observation= fields.Selection(selection=[('invalid', 'Invalid'),
                                        ('nonrenseign', 'Non renseigné')],
                                  string='Observation'
                                     )
    
class ProductTemplate(models.Model):
    _inherit = 'product.template'
          
    @api.one
    @api.constrains('default_code','alt_code')
    def _check_unique_constraint(self):
        #record = self.search([('name', '=ilike', self.name),('id','!=',self.id)])
        record1 = self.search([('default_code', '=ilike', self.default_code),('id','!=',self.id)])
        record2=self.search([('alt_code', '=ilike', self.alt_code),('id','!=',self.id)])
        if   record1 or record2:
            raise ValidationError(_('Un autre produit de même nom ou réference existe!'))
    
    @api.model
    def create(self, vals):
        res = super(ProductTemplate, self).create(vals)
        res.name = res.name.rstrip().lstrip()
        res.list_price = ((res.standard_price * res.margin_price) / 100) + res.standard_price

        return res
    
    @api.multi
    def write(self, vals):
        if 'name' in vals:
            vals['name'] = vals['name'].rstrip().lstrip()
        if 'default_code' in vals:
            vals['default_code'] = vals['default_code'].rstrip().lstrip()
        if 'alt_code' in vals:
            vals['alt_number'] = vals['alt_code'].rstrip().lstrip()
        #self.list_price = ((self.standard_price * self.margin_price) / 100) + self.standard_price
        #vals['list_price'] = ((vals['standard_price'] * vals['margin_price']) / 100) + vals['standard_price']

        return super(ProductTemplate, self).write(vals)

    @api.onchange("margin_price", "standard_price")
    def onchanginprice(self):
        if self.margin_price or self.standard_price:
         self.list_price = ((self.standard_price * self.margin_price) / 100) + self.standard_price

    default_code = fields.Char('Référence', required=True)
    alt_code = fields.Char('Alternative Number')
    margin_price=fields.Float('Margin Percentage',default=60.00)
    state = fields.Selection(selection=[('ne', 'NE'),
                                        ('sv', 'SV'),
                                        ('fn', 'FN'),
                                        ('oh', 'OH')],
                             string='Etat',
                             default='ne',
                             index=True)
    observation = fields.Selection(selection=[('invalid', 'Invalid'),
                                              ('nonrenseign', 'Non renseigné')],
                                   string='Observation'
                                   ,
                             index=True)