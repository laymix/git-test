## CHANGELOG FOR `1.1.x`

### v1.1.16 (2019-02-26)

#### TL;DR

- The first release after splitting the bundle to be a standalone package with its own release cycle.

#### Details

- [#10](https://github.com/Sylius/SyliusFixturesBundle/issues/10) Set up Travis CI for 1.1 ([@pamil](https://github.com/pamil))
