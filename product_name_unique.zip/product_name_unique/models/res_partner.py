# Copyright 2016 Antonio Espinosa
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl.html).

from odoo import _, api, models
from odoo.exceptions import ValidationError


class ResPartner(models.Model):
    _inherit = "res.partner"

    @api.one
    @api.constrains('name')
    def _check_ref(self):
        record = self.search([('name', '=ilike', self.name), ('id', '!=', self.id)])
        if record:
            raise ValidationError(_('Ce partenaire existe déja dans votre base de données !'))

    @api.model
    def create(self, vals):
        res = super(ResPartner, self).create(vals)
        res.name = res.name.rstrip().lstrip()

        return res

    @api.multi
    def write(self, vals):
        if 'name' in vals:
            vals['name'] = vals['name'].rstrip().lstrip()

        return super(ResPartner, self).write(vals)

