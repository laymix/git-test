# -*- coding: utf-8 -*-
{
    'name': "SW - Product Name Unique",
    'license':  "Other proprietary",
    'summary': "Makes the product name unique like the barcode",
    'author': "Smart Way Business Solutions",
    'website': "https://www.smartway-jo.com",
    'category': 'Warehouse',
    'version': '12.0.1.0',
    'depends': ['base','product'],
    'data': ['views/product_view.xml',
              ],
    'images':  ["static/description/image.png"],
    'auto_install': False,
}
