<?php

declare(strict_types=1);

namespace Brille24\SyliusCustomerOptionsPlugin\Exceptions;

use Exception;

class CustomerOptionValidatorException extends Exception
{
}
